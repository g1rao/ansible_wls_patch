package weblogic.management.security;

import weblogic.descriptor.DescriptorBean;
import weblogic.management.commo.StandardInterface;
import weblogic.management.security.audit.AuditorMBean;
import weblogic.management.security.authentication.AuthenticationProviderMBean;
import weblogic.management.security.authentication.PasswordValidatorMBean;
import weblogic.management.security.authentication.UserLockoutManagerMBean;
import weblogic.management.security.authorization.AdjudicatorMBean;
import weblogic.management.security.authorization.AuthorizerMBean;
import weblogic.management.security.authorization.RoleMapperMBean;
import weblogic.management.security.credentials.CredentialMapperMBean;
import weblogic.management.security.pk.CertPathBuilderMBean;
import weblogic.management.security.pk.CertPathProviderMBean;
import weblogic.management.utils.ErrorCollectionException;
import weblogic.management.VersionConstants;

import javax.management.InvalidAttributeValueException;
import javax.management.JMException;

/**
 * <p>The MBean that represents configuration attributes for the
 * security realm.</p>
 * 
 * <p>A security realm contains a set of security configuration settings,
 * including the list of security providers
 * to use (for example, for authentication and authorization).</p>
 * 
 * <p>Code using security can either use the default security realm
 * for the domain or refer to a particular security realm by name
 * (by using the JMX display name of the security realm).</p>
 * 
 * <p>One security realm in the WebLogic domain must have the <code>DefaultRealm</code>
 * attribute set to true. The security realm with the <code>DefaultRealm</code>
 * attribute set to true is used as the default
 * security realm for the WebLogic domain. Note that other available security realms
 * must have the <code>DefaultRealm</code> attribute set to false.</p>
 * 
 * <p>When WebLogic Server boots, it locates and uses the default security realm. The security realm is
 * considered active since it is used when WebLogic Server runs.
 * Any security realm that is not used when WebLogic Server runs is considered inactive.
 * All active security realms must be configured before WebLogic Server is boots.</p>
 * 
 * <p>Since security providers are scoped by realm, the
 * <code>Realm</code> attribute on a security provider
 * must be set to the realm that uses the provider.</p>
 *
 * @referenceable
 * @customizer weblogic.management.security.RealmImpl(new weblogic.management.commo.RequiredModelMBeanWrapper(this))
 *
 * @author Copyright(c) 2004,2017, Oracle and/or its affiliates. All rights reserved.
 * @publish-api --exclude-by-default for-public-api
 */
public interface RealmMBean extends StandardInterface, DescriptorBean
{

  /**
   * This is the name space into which the security XML schema
   * is created.
   *
   * @exclude
   */
  public static final String SECURITY_XML_NAMESPACE = VersionConstants.NAMESPACE_SECURITY;

  //----------------------------------------------------------------------------------------------------
  // Auditor attributes and methods
  //----------------------------------------------------------------------------------------------------

  /**
   * Returns the Auditing providers for this security realm (in invocation order).
   *
   * @arrayOrderSensitive true
   * @allowsSubTypes
   * @dynamic false
   * @include-api for-public-api
   * @VisibleToPartitions ALWAYS
   */
  AuditorMBean[] getAuditors();

  /**
   * Changes the invocation order of this security realm's Auditing providers.
   *
   * @param auditors - The new invocation order for this security realm's
   *  Auditing providers.  It should contain exactly the same Auditing providers
   *  that <code>getAuditors()</code> returns, except in a different order.
   *
   *  Note: For  the purpose of backward   compatibility with previous  releases of  WebLogic Server,
   *  <code>auditors</code> may also contain Auditing providers that do
   *  not already belong to this security realm and are not contained by another
   *  security realm.   In this circumstance, these Auditing providers will be moved to this
   *  security realm.  Similarly, <code>auditors</code> can be missing
   *  some of this security realm's current Auditing providers.  All
   *  missing Auditing providers will be removed from this security realm.
   *  These behaviors are deprecated in  this release of WebLogic Server and will be removed in
   *  a future release.
   *
   * @exception InvalidAttributeValueException
   *
   * @validator ProviderValidator.validateProviders((ProviderMBean[])param0)
   * @validatePropertyDeclaration false
   * @include-api for-public-api
   */
  void setAuditors(AuditorMBean[] auditors) throws InvalidAttributeValueException;

  /**
   * Returns the types of Auditing providers that may be created in this security realm,
   * for example, <code>weblogic.security.providers.audit.DefaultAuditor</code>.
   * Use this method to find the available types to pass to <code>createAuditor</code>
   *
   * @dynamic false
   * @transient
   * @include-api for-public-api
   */
  String[] getAuditorTypes();

  /**
   * Creates an Auditing provider in this security realm.
   * The new Auditing provider is added to the end of the list of
   * Auditing providers  configured in this security realm.
   *
   * @param name - The name of this Auditing provider, for example, <code>DefaultAuditor</code>
   *
   * @param type - The type of this Auditing provider, for example,
   *  <code>weblogic.security.providers.audit.DefaultAuditor</code>
   *  Use <code>getAuditorTypes</code> to find the list of types that may be specified.
   *
   * @exception ClassNotFoundException is thrown if an invalid type is specified.
   *
   * @exception JMException
   * @include-api for-public-api
   */
  AuditorMBean createAuditor(String name, String type) throws ClassNotFoundException, JMException;

  /**
   * Creates an Auditing provider in this security realm.
   * The new Auditing provider is added to the end of the list of
   * Auditing providers  configured in this security realm.
   *
   * @param type - The type of this Auditing provider, for example,
   *  <code>weblogic.security.providers.audit.DefaultAuditor</code>
   *  Use <code>getAuditorTypes</code> to find the list of types that may be specified.
   *
   * @exception ClassNotFoundException is thrown if an invalid type is specified.
   *
   * @exception JMException
   * @include-api for-public-api
   * @excludeFromRest REST only supports one creator
   */
  AuditorMBean createAuditor(String type) throws ClassNotFoundException, JMException;

  /**
   * @exclude
   *
   * @internal
   */
  AuditorMBean createAuditor(Class subInterface) throws JMException;

  /**
   * @exclude
   *
   * @internal
   */
  AuditorMBean createAuditor(Class subInterface, String name) throws JMException;

  /**
   * Removes the configuration for an Auditing provider in this security realm.
   * It does not remove any persistent data for the Auditing provider (such as databases or files).
   * <code>weblogic.management.configuration.SecurityConfigurationMBean.destroyRealm</code>
   * automatically removes the security realm's Auditing providers.
   *
   * @param auditor - The Auditing provider to remove.
   * @include-api for-public-api
   */
  void destroyAuditor(AuditorMBean auditor);

  /**
   * Finds an Auditing provider in this security realm.
   * Returns null if this security realm has no Auditing provider of the specified name.
   * @param name
   * @include-api for-public-api
   * @VisibleToPartitions ALWAYS
   */
  AuditorMBean lookupAuditor(String name);

  //----------------------------------------------------------------------------------------------------
  // AuthenticationProvider attributes and methods
  //----------------------------------------------------------------------------------------------------

  /**
   * Returns the Authentication providers for this security realm (in invocation order).
   *
   * @arrayOrderSensitive true
   * @allowsSubTypes
   * @dynamic false
   * @include-api for-public-api
   * @VisibleToPartitions ALWAYS
   */
  AuthenticationProviderMBean[] getAuthenticationProviders();

  /**
   * Changes the invocation order of this security realm's Authentication providers.
   *
   * @param authenticationProviders - The new invocation order for this security realm's
   *  Authentication providers.  It should contain exactly the same Authentication providers
   *  that <code>getAuthenticationProviders()</code> returns, except in a different order.
   *
   *  Note: For  the purpose of backward   compatibility with previous  releases of  WebLogic Server,
   *  <code>authenticationProviders</code> may also contain Authentication providers that do
   *  not already belong to this security realm and are not contained by another
   *  security realm.   In this circumstance, these Authentication providers will be moved to this
   *  security realm.  Similarly, <code>authenticationProviders</code> can be missing
   *  some of this security realm's current Authentication providers.  All
   *  missing Authentication providers will be removed from this security realm.
   *  These behaviors are deprecated in  this release of WebLogic Server and will be removed in
   *  a future release.
   *
   * @exception InvalidAttributeValueException
   *
   * @validatePropertyDeclaration false
   * @validator ProviderValidator.validateProviders((ProviderMBean[])param0)
   * @include-api for-public-api
   */
  void setAuthenticationProviders(AuthenticationProviderMBean[] authenticationProviders) throws InvalidAttributeValueException;

  /**
   * Returns the types of Authentication providers that may be created in this security realm,
   * for example, <code>weblogic.security.providers.authentication.DefaultAuthenticator</code>.
   * Use this method to find the available types to pass to <code>createAuthenticationProvider</code>
   *
   * @dynamic false
   * @transient
   * @include-api for-public-api
   */
  String[] getAuthenticationProviderTypes();

  /**
   * Creates an Authentication provider in this security realm.
   * The new Authentication provider is added to the end of the list of
   * Authentication providers  configured in this security realm.
   *
   * @param name - The name of this Authentication provider, for example, <code>DefaultAuthenticator</code>
   *
   * @param type - The type of this Authentication provider, for example,
   *  <code>weblogic.security.providers.authentication.DefaultAuthenticator</code>
   *  Use <code>getAuthenticationProviderTypes</code> to find the list of types that may be specified.
   *
   * @exception ClassNotFoundException is thrown if an invalid type is specified.
   *
   * @exception JMException
   * @include-api for-public-api
   */
  AuthenticationProviderMBean createAuthenticationProvider(String name, String type) throws ClassNotFoundException, JMException;

  /**
   * Creates an Authentication provider in this security realm.
   * The new Authentication provider is added to the end of the list of
   * Authentication providers  configured in this security realm.
   *
   * @param type - The type of this Authentication provider, for example,
   *  <code>weblogic.security.providers.authentication.DefaultAuthenticator</code>
   *  Use <code>getAuthenticationProviderTypes</code> to find the list of types that may be specified.
   *
   * @exception ClassNotFoundException is thrown if an invalid type is specified.
   *
   * @exception JMException
   * @include-api for-public-api
   * @excludeFromRest REST only supports one creator
   */
  AuthenticationProviderMBean createAuthenticationProvider(String type) throws ClassNotFoundException, JMException;

  /**
   * @exclude
   *
   * @internal
   */
  AuthenticationProviderMBean createAuthenticationProvider(Class subInterface) throws JMException;

  /**
   * @exclude
   *
   * @internal
   */
  AuthenticationProviderMBean createAuthenticationProvider(Class subInterface, String name) throws JMException;

  /**
   * Removes the configuration for an Authentication provider in this security realm.
   * It does not remove any persistent data for the Authentication provider (such as databases or files).
   * <code>weblogic.management.configuration.SecurityConfigurationMBean.destroyRealm</code>
   * automatically removes the security realm's Authentication providers.
   *
   * @param authenticationProvider - The Authentication provider to remove.
   * @include-api for-public-api
   */
  void destroyAuthenticationProvider(AuthenticationProviderMBean authenticationProvider);

  /**
   * Finds an Authentication provider in this security realm.
   * Returns null if this security realm has no Authentication provider of the specified name.
   * @param name
   * @include-api for-public-api
   * @VisibleToPartitions ALWAYS
   */
  AuthenticationProviderMBean lookupAuthenticationProvider(String name);

  //----------------------------------------------------------------------------------------------------
  // RoleMapper attributes and methods
  //----------------------------------------------------------------------------------------------------

  /**
   * Returns the Role Mapping providers for this security realm (in invocation order).
   *
   * @arrayOrderSensitive true
   * @allowsSubTypes
   * @dynamic false
   * @include-api for-public-api
   * @VisibleToPartitions ALWAYS
   */
  RoleMapperMBean[] getRoleMappers();

  /**
   * Changes the invocation order of this security realm's Role Mapping providers.
   *
   * @param roleMappers - The new invocation order for this security realm's
   *  Role Mapping providers.  It should contain exactly the same Role Mapping providers
   *  that <code>getRoleMappers()</code> returns, except in a different order.
   *
   *  Note: For  the purpose of backward   compatibility with previous  releases of  WebLogic Server,
   *  <code>roleMappers</code> may also contain Role Mapping providers that do
   *  not already belong to this security realm and are not contained by another
   *  security realm.   In this circumstance, these Role Mapping providers will be moved to this
   *  security realm.  Similarly, <code>roleMappers</code> can be missing
   *  some of this security realm's current Role Mapping providers.  All
   *  missing Role Mapping providers will be removed from this security realm.
   *  These behaviors are deprecated in  this release of WebLogic Server and will be removed in
   *  a future release.
   *
   * @exception InvalidAttributeValueException
   *
   * @validator ProviderValidator.validateProviders((ProviderMBean[])param0)
   * @validatePropertyDeclaration false
   * @include-api for-public-api
   */
  void setRoleMappers(RoleMapperMBean[] roleMappers) throws InvalidAttributeValueException;

  /**
   * Returns the types of Role Mapping providers that may be created in this security realm,
   * for example, <code>weblogic.security.providers.authorization.DefaultRoleMapper</code>.
   * Use this method to find the available types to pass to <code>createRoleMapper</code>
   *
   * @dynamic false
   * @transient
   * @include-api for-public-api
   */
  String[] getRoleMapperTypes();

  /**
   * Creates a Role Mapping provider in this security realm.
   * The new Role Mapping provider is added to the end of the list of
   * Role Mapping providers  configured in this security realm.
   *
   * @param name - The name of this Role Mapping provider, for example, <code>DefaultRoleMapper</code>
   *
   * @param type - The type of this Role Mapping provider, for example,
   *  <code>weblogic.security.providers.authorization.DefaultRoleMapper</code>
   *  Use <code>getRoleMapperTypes</code> to find the list of types that may be specified.
   *
   * @exception ClassNotFoundException is thrown if an invalid type is specified.
   *
   * @exception JMException
   * @include-api for-public-api
   */
  RoleMapperMBean createRoleMapper(String name, String type) throws ClassNotFoundException, JMException;

  /**
   * Creates a Role Mapping provider in this security realm.
   * The new Role Mapping provider is added to the end of the list of
   * Role Mapping providers  configured in this security realm.
   *
   * @param type - The type of this Role Mapping provider, for example,
   *  <code>weblogic.security.providers.authorization.DefaultRoleMapper</code>
   *  Use <code>getRoleMapperTypes</code> to find the list of types that may be specified.
   *
   * @exception ClassNotFoundException is thrown if an invalid type is specified.
   *
   * @exception JMException
   * @include-api for-public-api
   * @excludeFromRest REST only supports one creator
   */
  RoleMapperMBean createRoleMapper(String type) throws ClassNotFoundException, JMException;

  /**
   * @exclude
   *
   * @internal
   */
  RoleMapperMBean createRoleMapper(Class subInterface) throws JMException;

  /**
   * @exclude
   *
   * @internal
   */
  RoleMapperMBean createRoleMapper(Class subInterface, String name) throws JMException;

  /**
   * Removes the configuration for a Role Mapping provider in this security realm.
   * It does not remove any persistent data for the Role Mapping provider (such as databases or files).
   * <code>weblogic.management.configuration.SecurityConfigurationMBean.destroyRealm</code>
   * automatically removes the security realm's Role Mapping providers.
   *
   * @param roleMapper - The Role Mapping provider to remove.
   * @include-api for-public-api
   */
  void destroyRoleMapper(RoleMapperMBean roleMapper);

  /**
   * Finds a Role Mapping provider in this security realm.
   * Returns null if this security realm has no Role Mapping provider of the specified name.
   * @param name
   * @include-api for-public-api
   * @VisibleToPartitions ALWAYS
   */
  RoleMapperMBean lookupRoleMapper(String name);

  //----------------------------------------------------------------------------------------------------
  // Authorizer attributes and methods
  //----------------------------------------------------------------------------------------------------

  /**
   * Returns the Authorization providers for this security realm (in invocation order).
   *
   * @arrayOrderSensitive true
   * @allowsSubTypes
   * @dynamic false
   * @include-api for-public-api
   * @VisibleToPartitions ALWAYS
   */
  AuthorizerMBean[] getAuthorizers();

  /**
   * Changes the invocation order of this security realm's Authorization providers.
   *
   * @param authorizers - The new invocation order for this security realm's
   *  Authorization providers.  It should contain exactly the same Authorization providers
   *  that <code>getAuthorizers()</code> returns, except in a different order.
   *
   *  Note: For  the purpose of backward   compatibility with previous  releases of  WebLogic Server,
   *  <code>authorizers</code> may also contain Authorization providers that do
   *  not already belong to this security realm and are not contained by another
   *  security realm.   In this circumstance, these Authorization providers will be moved to this
   *  security realm.  Similarly, <code>authorizers</code> can be missing
   *  some of this security realm's current Authorization providers.  All
   *  missing Authorization providers will be removed from this security realm.
   *  These behaviors are deprecated in  this release of WebLogic Server and will be removed in
   *  a future release.
   *
   * @exception InvalidAttributeValueException
   *
   * @validator ProviderValidator.validateProviders((ProviderMBean[])param0)
   * @validatePropertyDeclaration false
   * @include-api for-public-api
   */
  void setAuthorizers(AuthorizerMBean[] authorizers) throws InvalidAttributeValueException;

  /**
   * Returns the types of Authorization providers that may be created in this security realm,
   * for example, <code>weblogic.security.providers.authorization.DefaultAuthorizer</code>.
   * Use this method to find the available types to pass to <code>createAuthorizer</code>
   *
   * @dynamic false
   * @transient
   * @include-api for-public-api
   */
  String[] getAuthorizerTypes();

  /**
   * Creates an Authorization provider in this security realm.
   * The new Authorization provider is added to the end of the list of
   * Authorization providers  configured in this security realm.
   *
   * @param name - The name of this Authorization provider, for example, <code>DefaultAuthorizer</code>
   *
   * @param type - The type of this Authorization provider, for example,
   *  <code>weblogic.security.providers.authorization.DefaultAuthorizer</code>
   *  Use <code>getAuthorizerTypes</code> to find the list of types that may be specified.
   *
   * @exception ClassNotFoundException is thrown if an invalid type is specified.
   *
   * @exception JMException
   * @include-api for-public-api
   */
  AuthorizerMBean createAuthorizer(String name, String type) throws ClassNotFoundException, JMException;

  /**
   * Creates an Authorization provider in this security realm.
   * The new Authorization provider is added to the end of the list of
   * Authorization providers  configured in this security realm.
   *
   * @param type - The type of this Authorization provider, for example,
   *  <code>weblogic.security.providers.authorization.DefaultAuthorizer</code>
   *  Use <code>getAuthorizerTypes</code> to find the list of types that may be specified.
   *
   * @exception ClassNotFoundException is thrown if an invalid type is specified.
   *
   * @exception JMException
   * @include-api for-public-api
   * @excludeFromRest REST only supports one creator
   */
  AuthorizerMBean createAuthorizer(String type) throws ClassNotFoundException, JMException;

  /**
   * @exclude
   *
   * @internal
   */
  AuthorizerMBean createAuthorizer(Class subInterface) throws JMException;

  /**
   * @exclude
   *
   * @internal
   */
  AuthorizerMBean createAuthorizer(Class subInterface, String name) throws JMException;

  /**
   * Removes the configuration for an Authorization provider in this security realm.
   * It does not remove any persistent data for the Authorization provider (such as databases or files).
   * <code>weblogic.management.configuration.SecurityConfigurationMBean.destroyRealm</code>
   * automatically removes the security realm's Authorization providers.
   *
   * @param authorizer - The Authorization provider to remove.
   * @include-api for-public-api
   */
  void destroyAuthorizer(AuthorizerMBean authorizer);

  /**
   * Finds an Authorization provider in this security realm.
   * Returns null if this security realm has no Authorization provider of the specified name.
   * @param name
   * @include-api for-public-api
   * @VisibleToPartitions ALWAYS
   */
  AuthorizerMBean lookupAuthorizer(String name);

  //----------------------------------------------------------------------------------------------------
  // Adjudicator attributes and methods
  //----------------------------------------------------------------------------------------------------

  /**
   * Returns the Adjudication provider for this security realm.
   *
   * @allowsSubTypes
   * @dynamic false
   * @include-api for-public-api
   * @VisibleToPartitions ALWAYS
   */
  AdjudicatorMBean getAdjudicator();

  /**
   * Returns the types of Adjudication providers that may be created in this security realm,
   * for example, <code>weblogic.security.providers.authorization.DefaultAdjudicator</code>.
   * Use this method to find the available types to pass to <code>createAdjudicator</code>
   *
   * @dynamic false
   * @transient
   * @include-api for-public-api
   */
  String[] getAdjudicatorTypes();

  /**
   * Creates an Adjudication provider in this security realm and removes
   * this security realm's previous Adjudication provider.
   *
   * @param name - The name of this Adjudication provider, for example, <code>DefaultAdjudicator</code>
   *
   * @param type - The type of this Adjudication provider, for example,
   *  <code>weblogic.security.providers.authorization.DefaultAdjudicator</code>
   *  Use <code>getAdjudicatorTypes</code> to find the list of types that may be specified.
   *
   * @exception ClassNotFoundException is thrown if an invalid type is specified.
   *
   * @exception JMException
   * @include-api for-public-api
   */
  AdjudicatorMBean createAdjudicator(String name, String type) throws ClassNotFoundException, JMException;

  /**
   * Creates an Adjudication provider in this security realm and removes
   * this security realm's previous Adjudication provider.
   *
   * @param type - The type of this Adjudication provider, for example,
   *  <code>weblogic.security.providers.authorization.DefaultAdjudicator</code>
   *  Use <code>getAdjudicatorTypes</code> to find the list of types that may be specified.
   *
   * @exception ClassNotFoundException is thrown if an invalid type is specified.
   *
   * @exception JMException
   * @include-api for-public-api
   * @excludeFromRest REST only supports one creator
   */
  AdjudicatorMBean createAdjudicator(String type) throws ClassNotFoundException, JMException;

  /**
   * @exclude
   *
   * @internal
   */
  AdjudicatorMBean createAdjudicator(Class subInterface) throws JMException;

  /**
   * @exclude
   *
   * @internal
   */
  AdjudicatorMBean createAdjudicator(Class subInterface, String name) throws JMException;

  /**
   * Removes the configuration this security realm's Adjudication provider (if there is one).
   * It does not remove any persistent data for the Adjudication provider (such as databases or files).
   * <code>weblogic.management.configuration.SecurityConfigurationMBean.destroyRealm</code>
   * automatically removes the security realm's Adjudication provider.
   * @include-api for-public-api
   */
  void destroyAdjudicator();

  //----------------------------------------------------------------------------------------------------
  // CredentialMapper attributes and methods
  //----------------------------------------------------------------------------------------------------

  /**
   * Returns the Credential Mapping providers for this security realm (in invocation order).
   *
   * @arrayOrderSensitive true
   * @allowsSubTypes
   * @dynamic false
   * @include-api for-public-api
   * @VisibleToPartitions ALWAYS
   */
  CredentialMapperMBean[] getCredentialMappers();

  /**
   * Changes the invocation order of this security realm's Credential Mapping providers.
   *
   * @param credentialMappers - The new invocation order for this security realm's
   *  Credential Mapping providers.  It should contain exactly the same Credential Mapping providers
   *  that <code>getCredentialMappers()</code> returns, except in a different order.
   *
   *  Note: For  the purpose of backward   compatibility with previous  releases of  WebLogic Server,
   *  <code>credentialMappers</code> may also contain Credential Mapping providers that do
   *  not already belong to this security realm and are not contained by another
   *  security realm.   In this circumstance, these Credential Mapping providers will be moved to this
   *  security realm.  Similarly, <code>credentialMappers</code> can be missing
   *  some of this security realm's current Credential Mapping providers.  All
   *  missing Credential Mapping providers will be removed from this security realm.
   *  These behaviors are deprecated in  this release of WebLogic Server and will be removed in
   *  a future release.
   *
   * @exception InvalidAttributeValueException
   *
   * @validator ProviderValidator.validateProviders((ProviderMBean[])param0)
   * @validatePropertyDeclaration false
   * @include-api for-public-api
   */
  void setCredentialMappers(CredentialMapperMBean[] credentialMappers) throws InvalidAttributeValueException;

  /**
   * Returns the types of Credential Mapping providers that may be created in this security realm,
   * for example, <code>weblogic.security.providers.credentials.DefaultCredentialMapper</code>.
   * Use this method to find the available types to pass to <code>createCredentialMapper</code>
   *
   * @dynamic false
   * @transient
   * @include-api for-public-api
   */
  String[] getCredentialMapperTypes();

  /**
   * Creates a Credential Mapping provider in this security realm.
   * The new Credential Mapping provider is added to the end of the list of
   * Credential Mapping providers  configured in this security realm.
   *
   * @param name - The name of this Credential Mapping provider, for example, <code>DefaultCredentialMapper</code>
   *
   * @param type - The type of this Credential Mapping provider, for example,
   *  <code>weblogic.security.providers.credentials.DefaultCredentialMapper</code>
   *  Use <code>getCredentialMapperTypes</code> to find the list of types that may be specified.
   *
   * @exception ClassNotFoundException is thrown if an invalid type is specified.
   *
   * @exception JMException
   * @include-api for-public-api
   */
  CredentialMapperMBean createCredentialMapper(String name, String type) throws ClassNotFoundException, JMException;

  /**
   * Creates a Credential Mapping provider in this security realm.
   * The new Credential Mapping provider is added to the end of the list of
   * Credential Mapping providers  configured in this security realm.
   *
   * @param type - The type of this Credential Mapping provider, for example,
   *  <code>weblogic.security.providers.credentials.DefaultCredentialMapper</code>
   *  Use <code>getCredentialMapperTypes</code> to find the list of types that may be specified.
   *
   * @exception ClassNotFoundException is thrown if an invalid type is specified.
   *
   * @exception JMException
   * @include-api for-public-api
   * @excludeFromRest REST only supports one creator
   */
  CredentialMapperMBean createCredentialMapper(String type) throws ClassNotFoundException, JMException;

  /**
   * @exclude
   *
   * @internal
   */
  CredentialMapperMBean createCredentialMapper(Class subInterface) throws JMException;

  /**
   * @exclude
   *
   * @internal
   */
  CredentialMapperMBean createCredentialMapper(Class subInterface, String name) throws JMException;

  /**
   * Removes the configuration for a Credential Mapping provider in this security realm.
   * It does not remove any persistent data for the Credential Mapping provider (such as databases or files).
   * <code>weblogic.management.configuration.SecurityConfigurationMBean.destroyRealm</code>
   * automatically removes the security realm's Credential Mapping providers.
   *
   * @param credentialMapper - The Credential Mapping provider to remove.
   * @include-api for-public-api
   */
  void destroyCredentialMapper(CredentialMapperMBean credentialMapper);

  /**
   * Finds a Credential Mapping provider in this security realm.
   * Returns null if this security realm has no Credential Mapping provider of the specified name.
   * @param name
   * @include-api for-public-api
   * @VisibleToPartitions ALWAYS
   */
  CredentialMapperMBean lookupCredentialMapper(String name);

  //----------------------------------------------------------------------------------------------------
  // CertPathProvider attributes and methods
  //----------------------------------------------------------------------------------------------------

  /**
   * Returns the Certification Path providers for this security realm (in invocation order).
   *
   * @arrayOrderSensitive true
   * @allowsSubTypes
   * @dynamic false
   * @include-api for-public-api
   * @VisibleToPartitions ALWAYS
   */
  CertPathProviderMBean[] getCertPathProviders();

  /**
   * Changes the invocation order of this security realm's Certification Path providers.
   *
   * @param certPathProviders - The new invocation order for this security realm's
   *  Certification Path providers.  It should contain exactly the same Certification Path providers
   *  that <code>getCertPathProviders()</code> returns, except in a different order.
   *
   * @exception InvalidAttributeValueException
   *
   * @validator ProviderValidator.validateProviders((ProviderMBean[])param0)
   * @validatePropertyDeclaration false
   * @include-api for-public-api
   */
  void setCertPathProviders(CertPathProviderMBean[] certPathProviders) throws InvalidAttributeValueException;

  /**
   * Returns the types of Certification Path providers that may be created in this security realm,
   * for example, <code>weblogic.security.providers.pk.WebLogicCertPathProvider</code>.
   * Use this method to find the available types to pass to <code>createCertPathProvider</code>
   *
   * @dynamic false
   * @transient
   * @include-api for-public-api
   */
  String[] getCertPathProviderTypes();

  /**
   * Creates a Certification Path provider in this security realm.
   * The new Certification Path provider is added to the end of the list of
   * Certification Path providers  configured in this security realm.
   *
   * The active security realm must contain at least one Certification Path
   * provider that is a CertPath Builder provider and at least one Certificate
   * Path provider that is a CertPath Validator provider.
   *
   * @param name - The name of this Certification Path provider, for example, <code>WebLogicCertPathProvider</code>
   *
   * @param type - The type of this Certification Path provider, for example,
   *  <code>weblogic.security.providers.pk.WebLogicCertPathProvider</code>
   *  Use <code>getCertPathProviderTypes</code> to find the list of types that may be specified.
   *
   * @exception ClassNotFoundException is thrown if an invalid type is specified.
   *
   * @exception JMException
   * @include-api for-public-api
   */
  CertPathProviderMBean createCertPathProvider(String name, String type) throws ClassNotFoundException, JMException;

  /**
   * Creates a Certification Path provider in this security realm.
   * The new Certification Path provider is added to the end of the list of
   * Certification Path providers  configured in this security realm.
   * <p>
   * The active security realm must contain at least one Certification Path
   * provider that is a CertPath Builder provider and at least one Certificate
   * Path provider that is a CertPath Validator provider.
   *
   * @param type - The type of this Certification Path provider, for example,
   *  <code>weblogic.security.providers.pk.WebLogicCertPathProvider</code>
   *  Use <code>getCertPathProviderTypes</code> to find the list of types that may be specified.
   *
   * @exception ClassNotFoundException is thrown if an invalid type is specified.
   *
   * @exception JMException
   * @include-api for-public-api
   * @excludeFromRest REST only supports one creator
   */
  CertPathProviderMBean createCertPathProvider(String type) throws ClassNotFoundException, JMException;

  /**
   * @exclude
   *
   * @internal
   */
  CertPathProviderMBean createCertPathProvider(Class subInterface) throws JMException;

  /**
   * @exclude
   *
   * @internal
   */
  CertPathProviderMBean createCertPathProvider(Class subInterface, String name) throws JMException;

  /**
   * Removes the configuration for a Certification Path provider in this security realm.
   * It does not remove any persistent data for the Certification Path provider (such as databases or files).
   * <code>weblogic.management.configuration.SecurityConfigurationMBean.destroyRealm</code>
   * automatically removes the security realm's Certification Path providers.
   * <p>
   * If <code>certPathProvider</code> has been selected as this security realm's
   * <code>CertPathBuilder</code>, then this security realm's will have no
   * <code>CertPathBuilder</code>.
   *
   * @param certPathProvider - The Certification Path provider to remove.
   * @include-api for-public-api
   */
  void destroyCertPathProvider(CertPathProviderMBean certPathProvider);

  /**
   * Finds a Certification Path provider in this security realm.
   * Returns null if this security realm has no Certification Path provider of the specified name.
   * @param name
   * @include-api for-public-api
   * @VisibleToPartitions ALWAYS
   */
  CertPathProviderMBean lookupCertPathProvider(String name);

  //----------------------------------------------------------------------------------------------------
  // CertPathBuilder attributes and methods
  //----------------------------------------------------------------------------------------------------

  /**
   * Returns the CertPath Builder provider in this security realm that will be used
   * by the security system to build certification paths.  Returns null if none has been
   * selected.  The provider will be one of this security realm's <code>CertPathProviders</code>.
   *
   * @dynamic false
   * @include-api for-public-api
   * @VisibleToPartitions ALWAYS
   */
  CertPathBuilderMBean getCertPathBuilder();

  /**
   * Determines which of this security realm's <code>CertPathProviders</code> will be used
   * by the security system to build certification paths.  The provider must implement
   * <code>weblogic.management.security.pk.CertPathBuilder</code>.
   *
   * @param certPathBuilder - The new CertPath Builder for this security realm.
   *  If null, this security realm will have no configured <code>CertPathBuilder</code>.
   *
   * @exception InvalidAttributeValueException
   *
   * @see #getCertPathBuilder()
   * @include-api for-public-api
   */
  void setCertPathBuilder(CertPathBuilderMBean certPathBuilder) throws InvalidAttributeValueException;

  //----------------------------------------------------------------------------------------------------
  // UserLockoutManager attributes and methods
  //----------------------------------------------------------------------------------------------------

  // Tag this attribute as allowsSubTypes to that the binder can handle
  // weblogic.management.security.authentication.UserLockoutManagerMBean.
  // Otherwise, the binder will only handle UserLockoutManagerMBean, and upgrade from 8.1 will fail.
  /**
   * Returns the User Lockout Manager for this security realm.
   *
   * @allowsSubTypes
   * @dynamic false
   * @include-api for-public-api
   */
  UserLockoutManagerMBean getUserLockoutManager();

  //----------------------------------------------------------------------------------------------------
  // Deployment attributes
  //----------------------------------------------------------------------------------------------------

  /**
   * Returns whether role deployment calls on the security system
   * are ignored or passed to the configured Role Mapping providers.
   *
   * @deprecated 9.0.0.0
   *
   * @dynamic true
   * @default false
   * @include-api for-public-api
   */
  boolean isDeployRoleIgnored();

  /**
   * Sets whether role deployment calls on the security system
   * are ignored or passed to the configured Role Mapping providers.
   *
   * @param ignored - the new deploy role ignored value
   * @exception InvalidAttributeValueException
   *
   * @see #isDeployRoleIgnored()
   * @deprecated 9.0.0.0
   * @include-api for-public-api
   */
  void setDeployRoleIgnored(boolean ignored) throws InvalidAttributeValueException;

  /**
   * Returns whether policy deployment calls on the security system
   * are ignored or passed to the configured Authorization providers.
   *
   * @deprecated 9.0.0.0
   *
   * @dynamic true
   * @default false
   * @include-api for-public-api
   */
  boolean isDeployPolicyIgnored();

  /**
   * Sets whether policy deployment calls on the security system
   * are ignored or passed to the configured Authorization providers.
   *
   * @param ignored - the new deploy policy ignored value
   * @exception InvalidAttributeValueException
   *
   * @see #isDeployPolicyIgnored()
   * @deprecated 9.0.0.0
   * @include-api for-public-api
   */
  void setDeployPolicyIgnored(boolean ignored) throws InvalidAttributeValueException;

  /**
   * Returns whether credential mapping deployment calls on the security system
   * are ignored or passed to the configured Credential Mapping providers.
   *
   * @deprecated 9.0.0.0
   *
   * @dynamic true
   * @default false
   * @include-api for-public-api
   */
  boolean isDeployCredentialMappingIgnored();

  /**
   * Sets whether credential mapping deployment calls on the security system
   * are ignored or passed to the configured Credential Mapping providers.
   *
   * @param ignored - the new deploy credential mapping ignored value.
   * @exception InvalidAttributeValueException
   *
   * @see #isDeployCredentialMappingIgnored()
   * @deprecated 9.0.0.0
   * @include-api for-public-api
   */
  void setDeployCredentialMappingIgnored(boolean ignored) throws InvalidAttributeValueException;

  /**
   * Returns whether the Web and EJB containers should
   * call the security framework on every access.
   * <p>
   * If false the containers are free to only call the security framework when
   * security is set in the deployment descriptors.
   *
   * @dynamic false
   * @default false
   * @deprecated 9.0.0.0
   * @include-api for-public-api
   */
  boolean isFullyDelegateAuthorization();

  /**
   * Sets whether the Web and EJB containers should
   * call the security framework on every access.
   *
   * @param fullyDelegate - the new fully delegate authorization value.
   * @exception InvalidAttributeValueException
   *
   * @see #isFullyDelegateAuthorization()
   * @deprecated 9.0.0.0
   * @include-api for-public-api
   */
  void setFullyDelegateAuthorization(boolean fullyDelegate) throws InvalidAttributeValueException;

  /*
   * Placeholder for Javadoc comment. This attribute was added early
   * in 9.0 but the related work for it was not completed and it's
   * not clear when the work can be completed but we cannot simply
   * remove an attribute from the configuration schema.
   *
   * <p>Specifies whether security deployment data should be validated.
   * The value of this attribute is defaulted from the same attribute in
   * the weblogic.management.security.RealmMBean unless overridden on
   * the deployment command line or by the deployment assistant. The
   * order of precedence for the value of this attribute is:
   * 1. The value set in the deployment command line or deployment assistant
   * 2. The value set in the realm's deployment security setting
   * 3. The value set in application's deployment security setting</p>
   */
  /**
   * <p>Not used in this release.</p>
   *
   * @dynamic true
   * @default false
   * @include-api for-public-api
   */
  boolean isValidateDDSecurityData();

  /**
   * Sets whether security data in the deployment descriptor is validated.
   * This setting establishes the default value for applications deployed using the realm.
   *
   * @param validate - the new validate deployment descriptor security data value.
   * @exception InvalidAttributeValueException
   *
   * @see #isValidateDDSecurityData()
   * @include-api for-public-api
   */
  void setValidateDDSecurityData(boolean validate) throws InvalidAttributeValueException;

  /**
   * <p>Specifies the default security model for Web applications or EJBs
   * that are secured by this security realm. You can override this default
   * during deployment.</p>
   * 
   * <p><b>Note:</b> If you deploy a module by modifying the domain's <code>config.xml</code> file
   * and restarting the server, and if you do not specify a security model value
   * for the module in <code>config.xml</code>, the module is secured with the default
   * value of the <code>AppDeploymentMBean SecurityDDModel</code>  attribute
   * (see {@link weblogic.management.configuration.AppDeploymentMBean#getSecurityDDModel() getSecurityDDModel}).</p>
   * 
   * <p>Choose one of these security models:</p>
   *    <ul>
   *       <li><code>Deployment Descriptors Only (DDOnly)</code>
   *         <ul>
   *           <li>For EJBs and URL patterns, this model uses only the roles
   *           and policies in the J2EE deployment descriptors (DD); the Administration
   *           Console allows only read access for this data. With this model,
   *           EJBs and URL patterns are not protected by roles and policies of a broader
   *           scope (such as a policy scoped to an entire Web application). If an EJB or
   *           URL pattern is not protected by a role or policy in the DD, then it is
   *           unprotected: anyone can access it. </li>
   *
   *           <li>For application-scoped <i>roles</i> in an EAR, this model uses only the roles
   *           defined in the WebLogic Server DD; the Administration Console allows only read
   *           access for this data. If the WebLogic Server DD does not define roles, then there
   *           will be no such scoped roles defined for this EAR.</li>
   *
   *           <li>For all other types of resources, you can use the Administration Console to
   *           create roles or policies. For example, with this model, you can use the Administration
   *           Console to create application-scoped <i>policies</i> for an EAR.</li>
   *
   *
   *          <li>Applies for the life of the deployment. If you want to use a
   *           different model, you must delete the deployment and reinstall
   *           it.</li>
   *         </ul>
   *       </li>
   *
   *       <li><code>Customize Roles Only (CustomRoles)</code>
   *         <ul>
   *           <li>For EJBs and URL patterns, this model uses only the <i>policies</i>
   *           in the J2EE deployment descriptors (DD). EJBs and URL
   *           patterns are not protected by policies of a broader scope (such as a
   *           policy scoped to an entire Web application). This model ignores any <i>roles</i>
   *           defined in the DDs; an administrator completes the role mappings using
   *           the Administration Console.</li>
   *
   *           <li>For all other types of resources, you can use the Administration Console to
   *           create roles or policies. For example, with this model, you can use the Administration
   *           Console to create application-scoped policies or roles for an EAR.</li>
   *
   *           <li>Applies for the life of the deployment. If you want to use a
   *           different model, you must delete the deployment and reinstall
   *           it.</li>
   *         </ul>
   *       </li>
   *
   *       <li><code>Customize Roles and Policies (CustomRolesAndPolicies)</code>
   *         <ul>
   *           <li>Ignores any roles and policies defined in deployment
   *           descriptors. An administrator uses the Administration Console to
   *           secure the resources.</li>
   *
   *           <li>Performs security checks for <b>all</b> URLs or EJB methods
   *           in the module.</li>
   *
   *           <li>Applies for the life of the deployment. If you want to use a
   *           different model, you must delete the deployment and reinstall
   *           it.</li>
   *         </ul>
   *       </li>
   *
   *       <li><code>Advanced (Advanced)</code>
   *       <p>You configure how this model behaves by setting values for
   *       the following options:</p>
   *         <ul>
   *           <li><code>When Deploying Web Applications or EJBs</code>
   *           <p><b>Note:</b> When using the WebLogic Scripting Tool or JMX APIs,
   *           there is no single MBean attribute for this setting. Instead,
   *            you must set the values for the <code>DeployPolicyIgnored</code> and
   *            <code>DeployRoleIgnored</code> attributes of <code>RealmMBean</code>.</p>
   *           </li>
   *
   *           <li><code>Check Roles and Policies (FullyDelegateAuthorization)</code></li>
   *
   *           <li><code>Combined Role Mapping Enabled (CombinedRoleMappingEnabled)</code></li>
   *         </ul>
   *         <p>You can change the configuration of this model. Any changes
   *       immediately apply to all modules that use the Advanced model. For
   *       example, you can specify that all modules using this model will copy
   *       roles and policies from their deployment descriptors into the
   *       appropriate provider databases upon deployment. After you deploy all
   *       of your modules, you can change this behavior to ignore roles and
   *       policies in deployment descriptors so that when you redeploy modules
   *       they will not re-copy roles and policies.</p>
   *           
   *      <p><b>Note:</b> Prior to WebLogic Server version 9.0 the Advanced model was
   *           the only security model available. Use this model if you want to
   *           continue to secure EJBs and Web Applications as in releases
   *           prior to 9.0.</p>
   *      </li>
   *     </ul>
   *
   * @see #isDeployPolicyIgnored()
   * @see #isDeployRoleIgnored()
   * @see #isFullyDelegateAuthorization()
   * @see #isCombinedRoleMappingEnabled()
   * @dynamic true
   * @legalValues DeploymentModel.DD_ONLY, DeploymentModel.CUSTOM_ROLES, DeploymentModel.CUSTOM_ROLES_POLICIES, DeploymentModel.ADVANCED
   * @default DeploymentModel.DD_ONLY
   * @include-api for-public-api
   */
  String getSecurityDDModel();

  /**
   * Sets the default security deployment model for applications deployed in this security realm.
   *
   * @param model - the new default security deployment model.
   * @exception InvalidAttributeValueException
   *
   * @see #getSecurityDDModel()
   * @include-api for-public-api
   */
  void setSecurityDDModel(String model) throws InvalidAttributeValueException;

  /**
   *     <p>Determines how the role mappings in the Enterprise Application, Web
   *     application, and EJB containers interact. This setting is valid only
   *     for Web applications and EJBs that use the Advanced security model and
   *     that initialize roles from deployment descriptors.</p>
   *     <p>When enabled:</p>
   *
   *     <ul>
   *       <li>Application role mappings are combined with EJB and Web
   *       application mappings so that all principal mappings are included.
   *       The Security Service combines the role mappings with a logical
   *       <code>OR</code> operator.</li>
   *
   *       <li>If one or more policies in the <code>web.xml</code> file
   *       specify a role for which no mapping exists in the
   *       <code>weblogic.xml</code> file, the Web application container
   *       creates an empty map for the undefined role (that is, the role is
   *       explicitly defined as containing no principal). Therefore, no one
   *       can access URL patterns that are secured by such policies.</li>
   *
   *       <li>If one or more policies in the <code>ejb-jar.xml</code> file
   *       specify a role for which no mapping exists in the
   *       <code>weblogic-ejb-jar.xml</code> file, the EJB container creates an
   *       empty map for the undefined role (that is, the role is explicitly
   *       defined as containing no principal). Therefore, no one can access
   *       methods that are secured by such policies.</li>
   *     </ul>
   *
   *     <p>When disabled:</p>
   *
   *     <ul>
   *       <li>Role mappings for each container are exclusive to other
   *       containers unless defined by the
   *       <code>&lt;externally-defined&gt;</code> descriptor element.</li>
   *
   *       <li><p>If one or more policies in the <code>web.xml</code> file
   *       specify a role for which no role mapping exists in the
   *       <code>weblogic.xml</code> file, the Web application container
   *       assumes that the undefined role is the name of a principal. It
   *       therefore maps the assumed principal to the role name. For example,
   *       if the <code>web.xml</code> file contains the following stanza in
   *       one of its policies:</p>
   *       
   *       <p><code>&lt;auth-constraint&gt;<br>
   *       &lt;role-name&gt;PrivilegedUser&lt;/role-name&gt;<br>
   *       &lt;/auth-constraint&gt;</code></p>
   *       
   *       <p>but, if the <code>weblogic.xml</code> file has no role mapping for
   *       <code>PrivilegedUser</code>, then the Web application container
   *       creates an in-memory mapping that is equivalent to the following
   *       stanza:</p>
   *       
   *       <p><code>&lt;security-role-assignment&gt;<br>
   *       &lt;role-name&gt;PrivilegedUser&lt;/role-name&gt;<br>
   *       &lt;principal-name&gt;PrivilegedUser&lt;/principal-name&gt;<br>
   *       &lt;/security-role-assignment&gt;</code></p>
   *       </li>
   *
   *       <li>Role mappings for EJB methods must be defined in the
   *       <code>weblogic-ejb-jar.xml</code> file. Role mappings defined in the
   *       other containers are not used unless defined by the
   *       <code>&lt;externally-defined&gt;</code> descriptor element.</li>
   *     </ul>
   *
   *     <dl>
   *       <dt>Note:</dt>
   *
   *       <dd>For all applications previously deployed in version 8.1 and
   *       upgraded to version 9.x, the combining role mapping is disabled by
   *       default.</dd>
   *     </dl>
   *
   * @since 9.0.0.0
   *
   * @dynamic true
   * @default true
   * @include-api for-public-api
   */
  boolean isCombinedRoleMappingEnabled();

  /**
   * Sets whether application role mappings are combined
   * by the J2EE containers.
   * <p>
   * If false the containers need enternally defined mappings
   * to use application role mappings.
   *
   * @param combined - the new combined role mapping value.
   * @exception InvalidAttributeValueException
   *
   * @see #isCombinedRoleMappingEnabled()
   * @since 9.0.0.0
   * @include-api for-public-api
   */
  void setCombinedRoleMappingEnabled(boolean combined) throws InvalidAttributeValueException;

  //----------------------------------------------------------------------------------------------------
  // Miscellaneous operations and attributes
  //----------------------------------------------------------------------------------------------------

  /**
   * Checks that the realm is valid.
   *
   * @exception ErrorCollectionException if this security realm is not valid.
   *  The exception contains a list of <code?java.lang.Exception</code>,
   *  one for each reason this security realm is not valid.  The text
   *  of each exception describes the problem.
   *
   * @deprecated 9.0.0.0 This method is no longer required since activating a configuration
   * transaction does this check automatically on the default realm, and will not allow
   * the configuration to be saved if the domain does not have a valid default realm configured.
   *
   * @operation
   * @include-api for-public-api
   */
  void validate() throws ErrorCollectionException;

  /**
   * Returns whether this security realm is the Default realm for the WebLogic domain.
   * Deprecated in this release of WebLogic Server and replaced by
   * <code>weblogic.management.configuration.SecurityConfigurationMBean.getDefaultRealm</code>.
   *
   * @deprecated 9.0.0.0 Replaced by {@link weblogic.management.configuration.SecurityConfigurationMBean#getDefaultRealm()}
   *
   * @dynamic false
   * @transient
   * @include-api for-public-api
   */
  boolean isDefaultRealm();

  /**
   * Determines whether is security realm is the Default realm for the WebLogic domain.
   * Deprecated in this release of WebLogic Server and replaced by
   * <code>weblogic.management.configuration.SecurityConfigurationMBean.setDefautlRealm</code>.
   *
   * @param isDefault - whether or not this security realm is the Default realm
   *  for the WebLogic domain.
   *
   * @exception InvalidAttributeValueException
   * @default false
   *
   * @deprecated 9.0.0.0  Replaced by {@link weblogic.management.configuration.SecurityConfigurationMBean#setDefaultRealm(weblogic.management.security.RealmMBean)}
   * @include-api for-public-api
   */
  void setDefaultRealm(boolean isDefault) throws InvalidAttributeValueException;

  /**
   * <p>Returns whether the WebLogic Principal Validator caching is enabled.</p>
   * 
   * <p>The Principal Validator is used by Oracle supplied authentication providers
   * and may be used by custom authentication providers. If enabled, the default principal
   * validator will cache WebLogic Principal signatures.</p>
   *
   * @dynamic false
   * @default true
   * @include-api for-public-api
   */
  boolean isEnableWebLogicPrincipalValidatorCache();

  /**
   * Sets whether the WebLogic Principal Validator caching is enabled.
   *
   * @param enabled - the new enable weblogic principal validator cache value.
   * @exception InvalidAttributeValueException
   *
   * @see #isEnableWebLogicPrincipalValidatorCache()
   * @include-api for-public-api
   */
  void setEnableWebLogicPrincipalValidatorCache(boolean enabled) throws InvalidAttributeValueException;

  /**
   * Returns the maximum size of the LRU cache for holding WebLogic Principal signatures.
   * This value is only used if <code>EnableWebLogicPrincipalValidatorCache</code> is set
   * to <code>true</code>
   *
   * @dynamic false
   * @validator weblogic.management.security.RealmValidator.validateMaxWebLogicPrincipalsInCache
   * @default new Integer(500)
   * @include-api for-public-api
   */
  Integer getMaxWebLogicPrincipalsInCache();

  /**
   * Sets the maximum size of the LRU cache for holding WebLogic Principal signatures.
   *
   * @param size - the new weblogic principals maximum cache size
   * @exception InvalidAttributeValueException
   *
   * @see #getMaxWebLogicPrincipalsInCache()
   * @include-api for-public-api
   */
  void setMaxWebLogicPrincipalsInCache(Integer size) throws InvalidAttributeValueException;

  //----------------------------------------------------------------------------------------------------
  // Standard COMMO mbean methods - need to re-declare in each base mbean to them get delegate properly
  //----------------------------------------------------------------------------------------------------

  /**
   * The name of this configuration. WebLogic Server uses an MBean to
   * implement and persist the configuration.
   *
   * @dynamic false
   * @legal (value != null) && (value.trim().length() > 0)
   * @default "Realm"
   * @include-api for-public-api
   * @VisibleToPartitions ALWAYS
   */
  String getName();

  /**
   * @exclude
   *
   * @internal
   */
  void setName(String value) throws InvalidAttributeValueException;

  /**
   * <p>Configures the WebLogic Server MBean servers to use the security realm's Authorization providers
   * to determine whether a JMX client has permission to access an MBean attribute or invoke an
   * MBean operation.</p>
   * <p>You can continue to use WebLogic Server's default security settings or modify
   * the defaults to suit your needs.</p>
   * <p>If you do not delegate authorization to the realm's Authorization providers, the WebLogic MBean servers
   * allow access only to the four default security roles (Admin, Deployer, Operator, and Monitor) and only
   * as specified by WebLogic Server's default security settings.</p>
   *
   * @dynamic false
   * @default false
   * @since 9.1.0.0
   * @include-api for-public-api
   */
  boolean isDelegateMBeanAuthorization();

  /**
   * Sets the value of the DelegateMBeanAuthorization attribute.
   *
   * @param deleteMBeanAuthorization - the new delegate MBean authorization value.
   * @exception InvalidAttributeValueException
   *
   * @see #isDelegateMBeanAuthorization()
   * @since 9.1.0.0
   * @include-api for-public-api
   */
  void setDelegateMBeanAuthorization(boolean deleteMBeanAuthorization) throws InvalidAttributeValueException;

  /**
   * Returns a comma separated string of authentication methods that should be
   * used when the Web application specifies "REALM" as its auth-method. The
   * authentication methods will be applied in order in which they appear in
   * the list.
   *
   * @dynamic false
   * @since 9.2.0.0
   * @include-api for-public-api
   */
  public String getAuthMethods();

  /**
   * Set the authentication methods that should be used when the Web
   * application specifies "REALM" as its auth-method.
   * @include-api for-public-api
   */
  public void setAuthMethods(String methods);

  /**
   * @exclude
   * @internal
   */
  public String getCompatibilityObjectName();

  /**
   * Returns RDBMSSecurityStoreMBean for this realm, which is a singleton MBean describing RDBMS
   * security store configuration.
   *
   * @return the reference to RDBMSSecurityStoreMBean or null if the RDBMS security store is not
   *         configured in this realm
   * @see #createRDBMSSecurityStore
   * @include-api for-public-api
   */
  RDBMSSecurityStoreMBean getRDBMSSecurityStore();

  /**
   * Creates configuration for the RDBMS security store. This can be called only once unless the existing
   * instance is destroyed by invoking <code>destroyRDBMSSecurityStore</code> operation. The new security store MBean
   * will have this realm as its parent.
   *
   * @return a RDBMS security store instance.
   * @throws JMException if an error occurs when creating a RDBMS security store
   * @see #destroyRDBMSSecurityStore
   * @include-api for-public-api
   * @excludeFromRest REST only supports one creator
   */
  RDBMSSecurityStoreMBean createRDBMSSecurityStore() throws JMException;

  /**
   * Creates configuration for the RDBMS security store with the specified name. This can be called only once unless
   * the existing instance is destroyed by invoking <code>destroyRDBMSSecurityStore</code> operation. The new security
   * store MBean will have this realm as its parent.
   *
   * @param name the name of this RDBMS security store
   * @return a RDBMS security store instance.
   * @throws JMException if an error occurs when creating a RDBMS security store
   * @see #destroyRDBMSSecurityStore
   * @include-api for-public-api
   */
  RDBMSSecurityStoreMBean createRDBMSSecurityStore(String name) throws JMException;

  /**
   * Destroys and removes the existing RDBMS security store which is a child of this
   * realm. It only removes the security store configuration, not any data persisted in the store.
   *
   * @see #createRDBMSSecurityStore
   * @include-api for-public-api
   */
  void destroyRDBMSSecurityStore();

    /**
   * Creates a Password Validator provider in this security
   * The new Password Validator provider is added to the end of the list of
   * Password Validator providers configured in this security realm.
   * @param subInterface Class The class of a Password Validator provider MBean implementation
   * @exclude
   * @since 10.0
   * @internal
   */
  public PasswordValidatorMBean createPasswordValidator(Class subInterface) throws JMException;

  /**
   * Exclude from public API to be consistent with other provider creators. 
   * Use createPasswordValidator(String, String) or createPasswordValidator(String) instead.
   * @exclude
   *
   * @internal
   */
  public PasswordValidatorMBean createPasswordValidator(Class subClass, String name) throws JMException;

  /**
   * Creates a Password Validator provider in this security realm.
   * The new Password Validator provider is added to the end of the list of
   * Password Validator providers configured in this security realm.
   * @since 10.0
   * @param name String The name for the given Password Validator provider MBean
   * @param type String The type of a Password Validator provider, all available types are in method <code>getPasswordValidatorTypes</code>
   * @return PasswordValidatorMBean
   * @throws ClassNotFoundException
   * @throws JMException
   * @include-api for-public-api
   */
  public PasswordValidatorMBean createPasswordValidator(String name, String type) throws ClassNotFoundException, JMException;

  /**
   * Creates a Password Validator provider in this security realm.
   * The new Password Validator provider is added to the end of the list of
   * Password Validator providers configured in this security realm.
   * @since 10.0
   * @param type String The type of a Password Validator provider, all available types are in method <code>getPasswordValidatorTypes</code>
   * @return PasswordValidatorMBean
   * @throws ClassNotFoundException
   * @throws JMException
   * @include-api for-public-api
   * @excludeFromRest REST only supports one creator
   */
  public PasswordValidatorMBean createPasswordValidator(String type) throws ClassNotFoundException, JMException;

  /**
   * Returns the types of Password Validator providers that may be created in this security realm,
   * for example, <code>com.bea.security.providers.authentication.passwordvalidator.SystemPasswordValidator</code>.
   * Use this method to find the available types to pass to <code>createPasswordValidator</code>
   * @since 10.0
   * @dynamic false
   * @transient
   * @include-api for-public-api
   */
  public String[] getPasswordValidatorTypes();

  /**
   * Returns the Password Validator providers for this security realm (in invocation order).
   * @since 10.0
   * @arrayOrderSensitive true
   * @allowsSubTypes
   * @dynamic false
   * @include-api for-public-api
   * @VisibleToPartitions ALWAYS
   */
  public PasswordValidatorMBean[] getPasswordValidators();

  /**
   * Sets the Password Validator providers for this security realm (in invocation order).
   * @param passwordvalidators - The password validator providers to be set for this security realm.
   * @exception InvalidAttributeValueException
   * @validator ProviderValidator.validateProviders((ProviderMBean[])param0)
   * @validatePropertyDeclaration false
   * @include-api for-public-api
   */
  void setPasswordValidators(PasswordValidatorMBean[] passwordvalidators) throws InvalidAttributeValueException;

  /**
   * Finds an Password Validator provider in this security realm.
   * Returns null if this security realm has no Password Validator provider with the specified name.
   * @since 10.0
   * @param name String The name of a Password Validator provider MBean
   * @return PasswordValidatorMBean
   * @include-api for-public-api
   * @VisibleToPartitions ALWAYS
   */
  public PasswordValidatorMBean lookupPasswordValidator(String name);

  /**
   * Removes the configuration for a Password Validator provider in this security realm.
   * @since 10.0
   * @param provider PasswordValidatorMBean The Password Validator provider to remove
   * @include-api for-public-api
   */
  public void destroyPasswordValidator (PasswordValidatorMBean provider);

  /**
   * <p>Specifies whether synchronization for deployable Authorization and Role Mapping providers is enabled.</p>
   * 
   * <p>The Authorization and Role Mapping providers may or may not support parallel security policy and role modification,
   * respectively, in the security provider database. If the security providers do not support parallel modification, 
   * the WebLogic Security Framework enforces a synchronization mechanism that results in each application and module 
   * being placed in a queue and deployed sequentially.</p>
   * 
   * @since 10.3
   * @dynamic false
   * @default false
   * @include-api for-public-api
   */
  public boolean isDeployableProviderSynchronizationEnabled();

  /**
   * Specifies whether synchronization for deployable Authorization and Role Mapping providers is enabled.
   *
   * @since 10.3
   * @param enabled - the new value indicating whether the synchronization for deployable Authorization and Role Mapping providers is enabled
   * @exception InvalidAttributeValueException
   * 
   * @see #isDeployableProviderSynchronizationEnabled()
   * @include-api for-public-api
   */
  public void setDeployableProviderSynchronizationEnabled(boolean enabled) throws InvalidAttributeValueException;

  
  /**
   * Returns the timeout value, in milliseconds, for the deployable security provider synchronization operation.
   * This value is only used if <code>DeployableProviderSynchronizationEnabled</code> is set
   * to <code>true</code>
   * 
   * @since 10.3
   * @dynamic false
   * @default new Integer(60000)
   * @include-api for-public-api
   */
  public Integer getDeployableProviderSynchronizationTimeout();

  /**
   * Specifies the timeout value, in milliseconds, for the deployable security provider synchronization operation.
   *
   * @since 10.3
   * @param timeout - the new timeout value (in milliseconds)
   * @exception InvalidAttributeValueException
   * 
   * @see #getDeployableProviderSynchronizationTimeout()
   * @include-api for-public-api
   */
  public void setDeployableProviderSynchronizationTimeout(Integer timeout) throws InvalidAttributeValueException;

  /**
   * <p>Specifies whether the Realm will be auto-restarted if
   * non-dynamic changes are made to the realm or providers within the realm.</p>
   *
   * @return The AutoRestartOnNonDynamicChanges value
   * @derivedDefault isDefaultRealm() ? false : true
   * @dynamic true
   * @since 12.2.1.0.0
   * @include-api for-public-api
   */
  boolean isAutoRestartOnNonDynamicChanges();

  /**
   * <p>Sets the value of the AutoRestartOnNonDynamicChanges attribute.</p>
   *
   * @see #isAutoRestartOnNonDynamicChanges
   * @param autorestart The new AutoRestartOnNonDynamicChanges value
   * @include-api for-public-api
   */
  void setAutoRestartOnNonDynamicChanges(boolean autorestart);

  /**
   * <p>Specifies the retire timeout for a realm that is restarted. The old
   * realm will be shutdown after the specified timeout period has elapsed.</p>
   *
   * @return The RealmRestartRetireTimeoutSeconds value
   * @default 60
   * @legalMin 1
   * @dynamic true
   * @since 12.2.1.0.0
   * @include-api for-public-api
   */
  int getRetireTimeoutSeconds();

  /**
   * <p>Sets the value of the RetireTimeoutSeconds attribute.</p>
   *
   * @see #getRetireTimeoutSeconds
   * @param timeout The new Retire Timeout Seconds value
   * @include-api for-public-api
   */
  void setRetireTimeoutSeconds(int timeout);

  /**
   * <p>Sets the Management Identity Domain value for the realm.</p>
   *
   * @return The Management Identity Domain value
   * @dynamic false
   * @since 12.2.1.1.0
   * @include-api for-public-api
   */
  String getManagementIdentityDomain();

  /**
   * <p>Sets the value of the Management Identity Domain attribute. Partition administrators
   * with this identity domain can invoke on a subset of management operations for the realm.
   * This allows the Partition Administrator to manage the realm data including users, groups,
   * roles, and policies.</p>
   *
   * @see #getManagementIdentityDomain
   * @param idd The new management identity domain value
   * @include-api for-public-api
   */
  void setManagementIdentityDomain(String idd);

  /**
   * <p>Obtain an ordered list of token type names used for Identity Assertion with HTTP request headers.</p>
   * 
   * <p>The list determines the precedence order when multiple HTTP headers are
   * present in an HTTP request based on the list of active token types maintained
   * on the configured Authentication providers.</p>
   *
   * @arrayOrderSensitive true
   * @default null
   * @dynamic true
   * @since 12.2.1.3.0
   * @include-api for-public-api
   */
  String[] getIdentityAssertionHeaderNamePrecedence();

  /**
   * <p>Set an ordered list of token type names used for Identity Assertion with HTTP request headers.</p>
   * 
   * <p>When specifying the HTTP Authorization header an optional colon followed by the
   * authentication scheme can be specified to further distinguish the precedence ordering,
   * for example, "Authorization: Bearer" would prefer the Bearer type of the credentials
   * in the Authorization header.</p>
   * 
   * @see #getIdentityAssertionHeaderNamePrecedence
   * @param names The ordered list of token type names
   * @include-api for-public-api
   */
  void setIdentityAssertionHeaderNamePrecedence(String[] names);
}
