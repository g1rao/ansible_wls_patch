===============================
Patch Set Update (PSU) for Bug: 26860993
===============================

Date:  Fri Dec  8 16:32:08 2017
---------------------------------
Platform Patch for : Generic
Product Patched : ORACLE WEBLOGIC SERVER
Product Version      : 12.2.1.2.0


This document describes how to install the interim patch for
bug #  26860993. It includes the following sections:

	Section 1, "Zero Downtime Patching"

 	Section 2, "Prerequisites"

	Section 3, "Pre-Installation Instructions"

	Section 4, "Installation Instructions"

	Section 5, "Post-Installation Instructions"

	Section 6, "Deinstallation Instructions"

	Section 7, "Post Deinstallation Instructions"

	Section 8, "Bugs Fixed by This Patch"

        Section 9, "Known Issues"


 
1 Zero Downtime Patching
------------------------------
This patch has been marked as eligible for Zero Downtime Patching. 
The type of Zero Downtime Patching supported by this patch is FMW_ROLLING_ORACLE_HOME.

With Zero Downtime Patching, a Patch can be applied to a system in a manner
that does not incur any downtime. This ensures that the system can remain
available and functioning during the patching process. Certain
pre-requisites, however, must be met before the patch can be applied.

For more information, consult the My Oracle Support MOS Note: 1942159.1 
 
2 Prerequisites
----------------
Ensure that you meet the following requirements before you install or
deinstall the patch:

1. Before applying the non-mandatory patches, ensure that you have the
exact symptoms described in the bug.


2. Oracle Fusion Middleware 12.2.1 products are installed with OPatch NextGen 13.3 to apply interim patches.

The OPatch utility should be updated over time to resolve known issues.

You can check your version using the following command:

ORACLE_HOME/OPatch/opatch version

Checking Patch 6880880, if a new version is available , download "OUI NextGen 13.3" for your platform.

Review the following for more information:
Doc ID 1587524.1, "Using OUI NextGen OPatch 13 for Oracle Fusion Middleware 12c (12.1.2+)"
https://support.oracle.com/rs?type=doc&id=1587524.1

For Oracle Fusion Middleware OPatch usage, refer to the URL below which
redirects to the latest FMW 12c document:
"Oracle Fusion Middleware Patching With OPatch"
 http://www.oracle.com/pls/topic/lookup?ctx=fmw122100&id=OPATC 

3. Verify the OUI Inventory.
OPatch needs access to a valid OUI inventory to apply patches.

Note: This needs the ORACLE_HOME to be set(refer section "2. Pre-Installation Instructions")
prior to run the below commands:

Validate the OUI inventory with the following commands:

$ opatch lsinventory -jre $ORACLE_HOME/oracle_common/jdk/jre

Note:
All OPatch commands should be run with -jre option.
Make sure the JDK version you use is the certified version for your product.

If the command errors out, contact Oracle Support and work to validate
and verify the inventory setup before proceeding.

4. Confirm the executables appear in your system PATH.

The patching process will use the unzip and the OPatch executables. After
setting the ORACLE_HOME environment, confirm if the following executables
exist, before proceeding to the next step:

- opatch
- unzip

If either of these executables do not show in the PATH, correct the
problem before proceeding.

5. Create a location for storing the unzipped patch. This location
will be referred to later in the document as PATCH_TOP.

NOTE: On WINDOWS, the preferred location is the drive root directory.
For example, "C:\PATCH_TOP" and avoid choosing locations like,
"C:\Documents and Settings\username\PATCH_TOP".
This is necessary due to the 256 characters limitation on windows
platform.

3 Pre-Installation Instructions
-------------------------------

1. Set the ORACLE_HOME environment variable to the directory where you have installed ORACLE WEBLOGIC SERVER.



4 Installation Instructions
---------------------------

1. Unzip the patch zip file into the PATCH_TOP.

$ unzip -d PATCH_TOP p26860993_122120_Generic.zip

NOTE: On WINDOWS, the unzip command has a limitation of 256 characters in the path name.
If you encounter this, please use an alternate ZIP utility like 7-Zip to unzip the patch.

For example: To unzip using 7-zip, run the command:
"c:\Program Files\7-Zip\7z.exe" x  p26860993_122120_Generic.zip

2. Set your current directory to the directory where the patch is located.

$ cd PATCH_TOP/26860993

3. Run OPatch to apply the patch.

$ opatch apply

Note:
-----
When OPatch starts, it validates the patch and makes sure that there are no
conflicts with the software already installed in the ORACLE_HOME.

In case of opatch conflict, you will see a warning message similar to the one mentioned below:

Interim Patch XXXX has Conflict with patch(es) [ YYYY ] in OH ...
Conflict patches: YYYY
Patch(es) YYYY conflict with the patch currently being installed (XXXX).
If you continue, patch(es) YYYY will be rolled back and the new patch (XXXX) will be installed.

If a merge of the new patch (XXXX) and the conflicting patch(es) ( YYYY) is required,contact Oracle Support Services and request a Merged patch.

Do you want to proceed? [y|n]
n

You must stop the patch installation and contact oracle support on how to proceed.

5 Post-Installation Instructions
---------------------------------

NONE


6 Deinstallation Instructions
------------------------------

If you experience any problems after installing this patch, remove the patch as
follows:

1. Make sure to follow the same Prerequisites or pre-install steps (if any)
when deinstalling a patch.
This includes setting up any environment variables like ORACLE_HOME and
verifying the OUI inventory before deinstalling.

2. Change to the directory where the patch was unzipped.

$ cd PATCH_TOP/26860993

3. Run OPatch to deinstall the patch.

$ opatch rollback -id  26860993

7 Post Deinstallation Instructions
-----------------------------------
Restart all servers (AdminServer and all Managed server(s)).

This is necessary to redeploy the original applications and bring the
environment back to it's original state.

8 Bugs Fixed by This Patch
--------------------------
 23099318: Fix for Bug 23099318
 26088242: WLS WEBSERVICES BASE COMPONENT LIBRARIES FOR ODI FEDERATED ORACLE HOME
 26151857: CODEHAUS COMPONENT LIBRARIES FOR ODI FEDERATED ORACLE HOME
 26151991: WLS SHARED INST COMPONENT LIBRARIES FOR ODI FEDERATED ORACLE HOME
 26080417: WLS SENT 0000 DATA TO THE CLIENT AFTER HTTP 204
 26985581: WLS PATCH SET UPDATE 12.1.3.0.171017 THROWING STRINGINDEXOUTOFBOUNDSEXCEPTION
 23101385: [BLOCKING JCS 12.2.1]: APP ACCESS GIVES 404 FOR SOME PARTITION/CLUSTER MEMBERS
 26144830: Fix for Bug 26144830
 25590885: DISABLED SMTP NOTIFICATION CAUSES SERVER TO START IN ADMIN STATE
 25564218: MISSING APPLICATION ID IN CIC
 26088843: WEBSERVICES OSDL COMPONENT LIBRARIES FOR ODI FEDERATED ORACLE HOME
 26089167: WLS LIBRARIES COMPONENT LIBRARIES FOR ODI FEDERATED ORACLE HOME
 26248394: Fix for Bug 26248394
 26828499: WLS REWRITES HOST HEADER WHEN CLUSTER FRONTEND ADDRESS IS SET
 25164167: TRACKING BUG FOR BACKPORT CIE BUG 25112723
 23762529: MT: STRESS:WLS: MBEANS TAKING MORE TIME
 25059150: Fix for Bug 25059150
 24445797: MAA:UPDATING RESTART IN PLACE PROPERTIES REQUIRES RESTART OF THE ENTIRE DOMAIN
 25742514: PSR:PERF EXTRA RESERVED DATABASE CONNECTIONS IN 12.2.1.2.0
 26138767: WLS.JRF.TENANCY COMP LIBRARIES FOR ODI FED ORACLE HOME
 25665727: <MENTORING BUG> ADMIN SERVER IS CONSUMING HIGH NATIVE MEMORY
 26044754: Fix for Bug 26044754
 26075541: .APPMERGEGEN_$DIGIT DIR REMAIN EVERY TIME BY DEPLOYING A EAR ON WLS 12.2.1
 24929178: .APPMERGEGEN_$DIGIT DIRECTORIES REMAIN EVERYTIME BY DEPLOYING A WAR ON WLS 12.2.
 21897691: STRESS OSB- STUCK THREAD DURING HARRIS STRESS TESTING
 24654879: WARNING MESSAGE REPEATEDLY LOGGED WHEN JDBC STORE IS ENABLED
 27111664: TRACKING BUG TO CONSUME JRF WEBSERVICES FIXES FOR 25990003 INTO WLS PSUS
 24849618: WLS LOSES CONNECTION WITH MANAGED SERVER AFTER ADMIN SERVER RESTART
 25203951: DUPLICATE DEPLOYERRUNTIMETEXTTEXTLOCALIZER_JA.PROPERTIES FILES
 22821346: 12.2.1.1[ST3]:"SERVICE BUS ROUTING" APP FAILS TO START
 24818026: Fix for Bug 24818026
 26589850: IMPROVE DOMAINRUNTIME.GETSERVERRUNTIME() PERFORMANCE
 25812313: RESTFUL MANAGEMENT LEADS TO MEMORY LEAK IN WEBLOGIC.RMI.INTERNAL.OIDMANAGER
 26547016: Fix for Bug 26547016
 25078137: FOH: DEFINE COMPONENT LIBRARIES IN WLS COMPONENTS FOR SOA FOH
 25534314: REMOVE UNUSED CA FROM DEMOTRUST.JKS
 24533963: Fix for Bug 24533963
 25565231: ENCRYPTED PASSWORD FOR MAILSESSIONOVERRIDE IS NOT PERSISTED
 26131926: WLS WLS PORTABLE MOD COMPONENT LIBRARIES FOR ODI FEDERATED ORACLE HOME
 25743005: Fix for Bug 25743005
 24521759: NULL HTTPSESSION AFTER THE FIRST REQUEST IS REDIRECTED
 25750303: COMMONDOMAIN:WC_COLLABORATION=RUNNING,HEALTH_NULL
 26371333: TRACKING BUG FOR DIAGNOSTIC PATCH OF IDCS INTEGRATION PS3 CHANGES
 27117282: CERTGEN FAILS WITH JDK8 CPU (180161, B04, B05, B06)
 26835012: UPG-20170919:GSI:EBNN-TEST:WC_SPACES FAILS TO COME UP CANNOT INSERT WC_PORTAL_PR
 24963946: TRACKING BUG FOR DIAGNOSTIC PATCH OF IDCS INTEGRATION
 26197660: WLST ONLINE FAILED ON CREATE FAIRESHARECONSTRAINT OF RESOUCEMANAGER
 24817968: Fix for Bug 24817968
 25743025: Fix for Bug 25743025
 25823774: Fix for Bug 25823774
 25522149: WS TEST CLIENT LINK REDIRECTION ISSUE UNDER PRODUCTION MODE
 27055227: TRACKING BUG FOR DIAGNOSTIC PATCH OF IDCS INTEGRATION 12.3.1 CHANGES


9 Known Issues
------------
For information about OPatch issues, see My Oracle Support Document 293369.1
Master Note for OPatch

For issues documented after the release of this ORACLE WEBLOGIC SERVER Patch Set Update, see My Oracle Support Document <2137518.1>  <(Known Issues for Oracle WebLogic Server (OWLS) 12.2.1.0.X Patch Set Updates)>

-----------------------------------------------------------------------------
DISCLAIMER:

This interim patch has only undergone basic unit testing, and has not been
through a complete test cycle generally followed for a production patch set.
Though the fixes in this document rectifies the bug, Oracle Corporation will
not be responsible for other issues that may arise due to these fixes.
Oracle Corporation recommends to later upgrade to the next production patch
set, when available. Applying this patch could overwrite other interim
patches applied since the last patch set. Customers need to make a request
to Oracle Support for a patch that includes those fixes, as well as inform
Oracle Support about all the patches installed when a Service Request is
opened. Please download, test, and provide feedback as soon as possible
to assist in the timely resolution of this problem.

Copyright (c)  2017, Oracle and/or its affiliates. All rights reserved.
----------------------------------------------------------------------------- 
